NFS MW GARAGE EXPAND
200-car garage expansion for Need for Speed: Most Wanted (2005)

INSTALL
1. Back up your career save and your existing Scripts\NFSMWExtraOptionsSettings.ini.
2. Extract this ZIP into the game's root folder (the folder containing speed.exe).
3. Allow the files under Scripts to be replaced.
4. Start the game and test with a backed-up or disposable career profile.

REQUIREMENTS
- Need for Speed: Most Wanted (2005), version 1.3 English.
- An ASI Loader that loads plugin files from the game's Scripts folder.

The included settings file sets PurchasedCarLimit to 200 and leaves other Extra
Options at their built-in defaults. If you already use Extra Options settings
you want to keep, back up your existing INI and add or change this line under
[Gameplay] instead of replacing your INI:

PurchasedCarLimit = 200

The game stores its original profile save separately. Extra garage records are
stored in a per-profile .garage file beside NFSMWExtraOptions.asi in Scripts.
Do not copy another player's .garage file into your game; it contains their
profile-specific data.

The native car table has room for up to 200 cars. The 26th-car case has been
confirmed, but the full 200-car limit has not yet been tested end-to-end.
Treat this as experimental and keep backups of your saves.

This plugin modifies GPL-3.0-licensed NFSMW Extra Options source. The complete
corresponding source code and license are available in the project repository.
